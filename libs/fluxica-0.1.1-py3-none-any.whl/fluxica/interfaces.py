# src/fluxica/interfaces.py

from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional
import polars as pl


class DataProvider(ABC):
    """
    Contrato obligatorio para todos los proveedores de datos.
    
    Cualquier implementación concreta DEBE:
    1. Heredar de esta clase
    2. Implementar todos los métodos abstractos
    3. Retornar DataFrames con el schema estandarizado
    """
    
    # Schema obligatorio de salida
    REQUIRED_COLUMNS = ["time", "open", "high", "low", "close", "volume"]
    
    @abstractmethod
    def fetch_history(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        granularity: str = "1d"
    ) -> pl.DataFrame:
        """
        Descarga datos históricos OHLCV para un símbolo.
        
        Args:
            symbol: Identificador del activo (ej: "AAPL", "EUR_USD")
            start_date: Fecha inicial (inclusive)
            end_date: Fecha final (inclusive)
            granularity: Resolución temporal ("1m", "5m", "1h", "1d")
        
        Returns:
            DataFrame de Polars con columnas:
            - time: Datetime[ns, UTC]
            - open: Float64
            - high: Float64
            - low: Float64
            - close: Float64
            - volume: Int64
        
        Raises:
            ValueError: Si el símbolo no es válido
            ConnectionError: Si falla la conexión al proveedor
        """
        pass
    
    @abstractmethod
    def get_supported_granularities(self) -> List[str]:
        """
        Retorna lista de granularidades soportadas por este proveedor.
        
        Returns:
            Lista de strings (ej: ["1m", "5m", "1h", "1d"])
        """
        pass
    
    @abstractmethod
    def validate_symbol(self, symbol: str) -> bool:
        """
        Verifica si el símbolo es válido para este proveedor.
        
        Args:
            symbol: Identificador a validar
            
        Returns:
            True si es válido, False en caso contrario
        """
        pass
    
    def _validate_output_schema(self, df: pl.DataFrame) -> bool:
        """
        Valida que el DataFrame cumpla con el schema obligatorio.
        Método de utilidad para implementaciones concretas.
        """
        if df.is_empty():
            return True  # DataFrame vacío es válido
        
        missing = set(self.REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Columnas faltantes en output: {missing}")
        
        # Validar que 'time' sea datetime con timezone UTC y precisión 'ns'
        time_dtype = df.schema.get("time")
        if time_dtype is None:
            raise ValueError("Columna 'time' no encontrada")
            
        # Check strict strict type
        expected_type = pl.Datetime("ns", "UTC")
        if time_dtype != expected_type:
             raise ValueError(f"Columna 'time' debe ser {expected_type}, encontrado: {time_dtype}")
        
        return True