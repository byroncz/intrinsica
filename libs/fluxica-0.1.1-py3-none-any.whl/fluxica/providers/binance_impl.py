# src/fluxica/providers/binance_impl.py
"""
Proveedor de datos históricos para Binance Vision.

Binance Vision (data.binance.vision) aloja volcados mensuales y diarios
de datos de mercado en formato CSV comprimido. Este proveedor implementa
la descarga masiva de:
- Klines (velas OHLCV) - Compatible con schema estándar fluxica
- AggTrades (operaciones agregadas) - Schema extendido para tick data

Referencia técnica:
- Los archivos ZIP incluyen checksums SHA256 para validación
- Datos disponibles: spot, futures (um/cm)
- Granularidades klines: 1s, 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 3d, 1w, 1mo
"""

import polars as pl
import requests
import zipfile
import hashlib
import io
import tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Literal, Dict, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from decimal import Decimal
import time
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn
from rich.console import Console
from rich import print as rprint

from ..interfaces import DataProvider
from ..utils import (
    normalize_timezone_to_utc,
    ensure_float64_prices,
    ensure_int64_volume,
    remove_duplicates,
)


from rich.text import Text

class SmartDownloadColumn(DownloadColumn):
    """Muestra X/Y files si es tarea de archivos, o bytes si es descarga."""
    def render(self, task) -> Text:
        if task.fields.get("status") == "processing":
            return Text("Processing...", style="yellow")
        if task.fields.get("type") == "files":
            return Text(f"{int(task.completed)}/{int(task.total)} files", style="progress.download")
        return super().render(task)

class SpeedColumn(TransferSpeedColumn):
    """Muestra velocidad solo si es descarga de bytes y no ha terminado."""
    def render(self, task) -> Text:
        if task.fields.get("status") == "processing":
            return Text("")
        if task.fields.get("type") == "files" or task.finished:
            return Text("")
        return super().render(task)


class BinanceVisionProvider(DataProvider):
    """
    Proveedor de datos históricos desde Binance Vision (archivos estáticos).
    
    Binance Vision es un servidor de archivos públicos que aloja volcados
    mensuales y diarios de datos de mercado. Esta es la fuente recomendada
    para backfill histórico masivo (años de datos).
    
    Ventajas sobre API REST:
    - No consume límites de peso de la API de trading
    - Descarga significativamente más rápida (archivos comprimidos)
    - Verificación de integridad mediante checksums SHA256
    
    Limitaciones:
    - Latencia de disponibilidad: datos diarios aparecen T+1
    - No incluye datos en tiempo real
    
    Tipos de datos soportados:
    - Klines (OHLCV): Compatible con schema estándar fluxica
    - AggTrades: Operaciones agregadas tick-by-tick
    
    Example:
        >>> from fluxica import ProviderFactory
        >>> binance = ProviderFactory.create("binance_vision")
        >>> 
        >>> # Descargar velas diarias
        >>> df = binance.fetch_history(
        ...     "BTCUSDT",
        ...     datetime(2023, 1, 1),
        ...     datetime(2023, 12, 31),
        ...     granularity="1d"
        ... )
        >>> 
        >>> # Descargar operaciones agregadas
        >>> trades = binance.fetch_agg_trades(
        ...     "BTCUSDT",
        ...     datetime(2024, 1, 1),
        ...     datetime(2024, 1, 31)
        ... )
    """
    
    # URL base de Binance Vision
    BASE_URL = "https://data.binance.vision/data"
    
    # Granularidades soportadas para klines
    KLINE_GRANULARITIES = [
        "1s", "1m", "3m", "5m", "15m", "30m",
        "1h", "2h", "4h", "6h", "8h", "12h",
        "1d", "3d", "1w", "1mo"
    ]
    
    # Mapeo de granularidad fluxica -> Binance
    GRANULARITY_MAP = {
        "1m": "1m",
        "5m": "5m",
        "15m": "15m",
        "30m": "30m",
        "1h": "1h",
        "4h": "4h",
        "1d": "1d",
        "1wk": "1w",
        "1mo": "1mo",
    }
    
    # Columnas de klines según documentación Binance
    KLINE_COLUMNS = [
        "open_time",        # Timestamp apertura (ms)
        "open",             # Precio apertura
        "high",             # Precio máximo
        "low",              # Precio mínimo
        "close",            # Precio cierre
        "volume",           # Volumen en base asset
        "close_time",       # Timestamp cierre (ms)
        "quote_volume",     # Volumen en quote asset
        "trades_count",     # Número de trades
        "taker_buy_volume", # Volumen compra taker (base)
        "taker_buy_quote",  # Volumen compra taker (quote)
        "ignore"            # Campo ignorado
    ]
    
    # Columnas de aggTrades
    AGGTRADE_COLUMNS = [
        "agg_trade_id",     # ID de operación agregada
        "price",            # Precio
        "quantity",         # Cantidad
        "first_trade_id",   # Primer trade ID del agregado
        "last_trade_id",    # Último trade ID del agregado
        "timestamp",        # Timestamp (ms)
        "is_buyer_maker",   # True si comprador fue maker
        "is_best_match"     # Campo legacy (ignorar)
    ]
    
    # Workers por defecto para descargas paralelas
    DEFAULT_MAX_WORKERS = 4
    
    # Timeout para requests HTTP (segundos)
    REQUEST_TIMEOUT = 30
    
    # Reintentos máximos por archivo
    MAX_RETRIES = 3
    
    def __init__(
        self,
        market_type: Literal["spot", "futures_um", "futures_cm"] = "spot",
        max_workers: int = DEFAULT_MAX_WORKERS,
        verify_checksum: bool = True,
        use_decimal: bool = False,
    ):
        """
        Inicializa el proveedor de Binance Vision.
        
        Args:
            market_type: Tipo de mercado a consultar:
                - "spot": Mercado spot (default)
                - "futures_um": Futuros USDT-Margined
                - "futures_cm": Futuros Coin-Margined
            max_workers: Hilos máximos para descargas paralelas (1-8)
            verify_checksum: Si True, verifica SHA256 de cada archivo
            use_decimal: Si True, usa Decimal para precios (mayor precisión,
                        menor rendimiento). Default False usa Float64.
        """
        self.market_type = market_type
        self.max_workers = max(1, min(max_workers, 8))
        self.verify_checksum = verify_checksum
        self.use_decimal = use_decimal
        
        # Construir path base según tipo de mercado
        self._base_path = self._get_base_path(market_type)
    
    def _get_base_path(self, market_type: str) -> str:
        """Construye el path base según el tipo de mercado."""
        paths = {
            "spot": "spot",
            "futures_um": "futures/um",
            "futures_cm": "futures/cm",
        }
        return paths.get(market_type, "spot")
    
    def fetch_history(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        granularity: str = "1d"
    ) -> pl.DataFrame:
        """
        Descarga datos históricos de klines (velas OHLCV).
        
        Implementa la interface DataProvider con schema estándar fluxica.
        
        Args:
            symbol: Par de trading (ej: "BTCUSDT", "ETHUSDT")
            start_date: Fecha inicial (inclusive)
            end_date: Fecha final (inclusive)
            granularity: Resolución temporal. Opciones:
                        "1m", "5m", "15m", "30m", "1h", "4h", "1d", "1wk", "1mo"
        
        Returns:
            DataFrame de Polars con columnas:
            - time: Datetime[μs, UTC]
            - open: Float64
            - high: Float64
            - low: Float64
            - close: Float64
            - volume: Int64
            
        Raises:
            ValueError: Si granularidad no es válida
            ConnectionError: Si falla la descarga
        """
        # Normalizar símbolo
        symbol = symbol.upper().replace("/", "").replace("-", "")
        
        # Mapear granularidad
        binance_gran = self.GRANULARITY_MAP.get(granularity)
        if binance_gran is None:
            if granularity in self.KLINE_GRANULARITIES:
                binance_gran = granularity
            else:
                raise ValueError(
                    f"Granularidad '{granularity}' no soportada. "
                    f"Opciones: {list(self.GRANULARITY_MAP.keys())}"
                )
        
        # Generar lista de archivos a descargar
        file_urls = self._generate_kline_urls(
            symbol, binance_gran, start_date, end_date
        )
        
        if not file_urls:
            return self._empty_kline_dataframe()
        
        # Descargar archivos en paralelo
        dataframes = self._download_files_parallel(
            file_urls,
            parser_func=self._parse_kline_csv,
            data_type="klines"
        )
        
        if not dataframes:
            return self._empty_kline_dataframe()
        
        # Concatenar y normalizar
        df = pl.concat(dataframes, how="diagonal")
        df = self._normalize_klines(df, start_date, end_date)
        
        # Validar schema
        self._validate_output_schema(df)
        
        return df
    
    def fetch_agg_trades(
        self,
        symbol: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        year: Optional[int] = None,
        month: Optional[int] = None,
        direction_as_sign: bool = True,
    ) -> pl.DataFrame:
        """
        Descarga operaciones agregadas (aggTrades) tick-by-tick.
        
        Permite especificar fechas exactas (start_date, end_date) O
        un mes completo (year, month).
        
        Args:
            symbol: Par de trading (ej: "BTCUSDT")
            start_date: Fecha inicial (inclusive). Opcional si se usa year/month.
            end_date: Fecha final (inclusive). Opcional si se usa year/month.
            year: Año deseado (ej: 2024). Requerido si no hay start_date.
            month: Mes deseado (ej: 1). Requerido si no hay start_date.
            direction_as_sign: Si True, convierte is_buyer_maker a:
                              +1 (compra agresiva), -1 (venta agresiva)
        """
        # Validar argumentos de fecha
        if start_date is None and (year is None or month is None):
            raise ValueError("Debe especificar start_date/end_date O year/month")
            
        # Determinar rango de fechas
        if year is not None and month is not None:
             # Calcular primer y último día del mes
            month_start = datetime(year, month, 1, tzinfo=timezone.utc)
            if month == 12:
                next_month = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
            else:
                next_month = datetime(year, month + 1, 1, tzinfo=timezone.utc)
            month_end = next_month - timedelta(microseconds=1)
            
            # Usar rango del mes si no se especificaron fechas exactas
            if start_date is None:
                start_date = month_start
            if end_date is None:
                end_date = month_end

        # Asegurar fechas UTC si no lo están (defensive)
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)

        # Normalizar símbolo
        symbol = symbol.upper().replace("/", "").replace("-", "")
        
        # Generar URLs
        file_urls = self._generate_aggtrade_urls(symbol, start_date, end_date)
        
        if not file_urls:
            return self._empty_aggtrade_dataframe(direction_as_sign)
        
        # Descargar en paralelo
        dataframes = self._download_files_parallel(
            file_urls,
            parser_func=self._parse_aggtrade_csv,
            data_type="aggTrades"
        )
        
        if not dataframes:
            return self._empty_aggtrade_dataframe(direction_as_sign)
        
        # Concatenar
        df = pl.concat(dataframes, how="diagonal")
        df = self._normalize_aggtrades(df, start_date, end_date, direction_as_sign)
        
        return df
    
    def _generate_kline_urls(
        self,
        symbol: str,
        granularity: str,
        start_date: datetime,
        end_date: datetime,
    ) -> List[Tuple[str, str]]:
        """
        Genera lista de URLs para descargar klines.
        
        Estrategia:
        - Usa archivos mensuales para meses completos del pasado
        - Usa archivos diarios para el mes actual/parcial
        
        Returns:
            Lista de tuplas (url_data, url_checksum)
        """
        # Init variables
        # Ensure dates are UTC
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)

        current = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

        def _yield_urls():
            curr = current
            while curr <= end_date:
                year = curr.year
                month = curr.month
                
                # Determinar si usar archivo mensual o diario
                next_month = (curr + timedelta(days=32)).replace(day=1)
                
                # Si el mes completo está en el pasado, usar archivo mensual
                if next_month < today:
                    # Archivo mensual
                    filename = f"{symbol}-{granularity}-{year}-{month:02d}"
                    url = f"{self.BASE_URL}/{self._base_path}/monthly/klines/{symbol}/{granularity}/{filename}.zip"
                    checksum_url = f"{url}.CHECKSUM"
                    yield (url, checksum_url)
                    curr = next_month
                else:
                    # Archivos diarios para el mes actual o meses recientes
                    days_in_month = (next_month - timedelta(days=1)).day
                    
                    for day in range(1, days_in_month + 1):
                        day_date = curr.replace(day=day)
                        
                        if day_date < start_date:
                            continue
                        if day_date > end_date:
                            break
                        if day_date >= today:
                            continue  # Datos de hoy no disponibles
                        
                        filename = f"{symbol}-{granularity}-{year}-{month:02d}-{day:02d}"
                        url = f"{self.BASE_URL}/{self._base_path}/daily/klines/{symbol}/{granularity}/{filename}.zip"
                        checksum_url = f"{url}.CHECKSUM"
                        yield (url, checksum_url)
                    
                    curr = next_month
        
        return list(_yield_urls())
    
    def _generate_aggtrade_urls(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
    ) -> List[Tuple[str, str]]:
        """Genera URLs para descargar aggTrades."""
        # Init variables
        # Ensure dates are UTC
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)

        current = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

        def _yield_urls():
            curr = current
            while curr <= end_date:
                year = curr.year
                month = curr.month
                next_month = (curr + timedelta(days=32)).replace(day=1)
                
                # Intentar archivo mensual primero
                if next_month < today:
                    filename = f"{symbol}-aggTrades-{year}-{month:02d}"
                    url = f"{self.BASE_URL}/{self._base_path}/monthly/aggTrades/{symbol}/{filename}.zip"
                    checksum_url = f"{url}.CHECKSUM"
                    yield (url, checksum_url)
                    curr = next_month
                else:
                    # Archivos diarios
                    days_in_month = (next_month - timedelta(days=1)).day
                    
                    for day in range(1, days_in_month + 1):
                        day_date = curr.replace(day=day)
                        
                        if day_date < start_date:
                            continue
                        if day_date > end_date:
                            break
                        if day_date >= today:
                            continue
                        
                        filename = f"{symbol}-aggTrades-{year}-{month:02d}-{day:02d}"
                        url = f"{self.BASE_URL}/{self._base_path}/daily/aggTrades/{symbol}/{filename}.zip"
                        checksum_url = f"{url}.CHECKSUM"
                        yield (url, checksum_url)
                    
                    curr = next_month
        
        return list(_yield_urls())
    
    def _download_files_parallel(
        self,
        file_urls: List[Tuple[str, str]],
        parser_func,
        data_type: str,
    ) -> List[pl.DataFrame]:
        """
        Descarga y parsea archivos en paralelo con monitoreo Rich y streaming.
        """
        dataframes = []

        console = Console()
        console.print(f"[bold cyan]Iniciando descarga de {data_type}...[/bold cyan]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            SmartDownloadColumn(),
            TimeElapsedColumn(),
            SpeedColumn(),
            console=console
        ) as progress:
            
            task_id = progress.add_task(f"[cyan]Descargando {len(file_urls)} archivo(s)...", total=len(file_urls), type="files")
            
            # Lock for thread-safe access to progress bar creation if needed (though rich is thread safe)
            
            def download_and_parse(url_tuple: Tuple[str, str]) -> Optional[pl.DataFrame]:
                data_url, checksum_url = url_tuple
                filename = data_url.split("/")[-1]
                
                for attempt in range(self.MAX_RETRIES):
                    download_task_id = None
                    try:
                        # 1. Descarga con Streaming
                        with requests.get(data_url, stream=True, timeout=self.REQUEST_TIMEOUT) as response:
                            if response.status_code == 404:
                                progress.console.log(f"[yellow]⚠️ No encontrado:[/yellow] {filename}")
                                return None
                            
                            response.raise_for_status()
                            
                            total_size = int(response.headers.get('content-length', 0))
                            
                            # Add temporary task for this file download
                            download_task_id = progress.add_task(
                                f"[green]Bajando {filename}...", 
                                total=total_size, 
                                visible=True,
                                transient=True,
                                type="bytes" 
                            )
                            
                            content_io = io.BytesIO()
                            for chunk in response.iter_content(chunk_size=8192):
                                if chunk:
                                    content_io.write(chunk)
                                    progress.update(download_task_id, advance=len(chunk))
                            
                            content = content_io.getvalue()
                        
                        # Mark as processing (don't remove yet)
                        if download_task_id is not None:
                            progress.update(download_task_id, status="processing")
                        
                        # 2. Checksum
                        if self.verify_checksum:
                           if not self._verify_sha256(content, checksum_url):
                                progress.console.log(f"[red]❌ Checksum inválido:[/red] {filename}")
                                raise ValueError(f"Checksum inválido para {data_url}")
                        
                        # 3. Descompresión y Parsing
                        df = self._decompress_and_parse(content, parser_func)
                        
                        progress.console.log(f"[bold green]✓ Completado:[/bold green] {filename} ({len(df)} filas)")
                        
                        # Finally remove task
                        if download_task_id is not None:
                            progress.remove_task(download_task_id)
                            download_task_id = None
                            
                        return df
                        
                    except requests.exceptions.RequestException:
                        if download_task_id is not None:
                            progress.remove_task(download_task_id)
                            
                        if attempt < self.MAX_RETRIES - 1:
                            time.sleep(2 ** attempt)
                            continue
                        progress.console.log(f"[red]Error red:[/red] {filename}")
                        return None
                    except Exception as e:
                        if download_task_id is not None:
                            progress.remove_task(download_task_id)
                        progress.console.log(f"[red]Error proc:[/red] {filename} - {str(e)}")
                        return None
                
                return None

            # Ejecutar en paralelo
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_url = {
                    executor.submit(download_and_parse, url_tuple): url_tuple
                    for url_tuple in file_urls
                }
                
                def result_generator():
                    for future in as_completed(future_to_url):
                        progress.advance(task_id)
                        try:
                            res = future.result()
                            if res is not None and not res.is_empty():
                                yield res
                        except Exception:
                            pass # Logged inside
                            
                dataframes = list(result_generator())
        
        console.print(f"[bold box]Proceso finalizado. {len(dataframes)} archivos procesados exitosamente.[/bold box]")
        return dataframes
    
    def _verify_sha256(self, content: bytes, checksum_url: str) -> bool:
        """Verifica el checksum SHA256 del contenido."""
        try:
            response = requests.get(checksum_url, timeout=10)
            if response.status_code != 200:
                return True  # Si no hay checksum, asumir OK
            
            # Formato: "sha256_hash  filename"
            expected_hash = response.text.strip().split()[0].lower()
            actual_hash = hashlib.sha256(content).hexdigest().lower()
            
            return expected_hash == actual_hash
        except Exception:
            return True  # En caso de error, continuar sin verificar
    
    def _decompress_and_parse(
        self,
        content: bytes,
        parser_func
    ) -> pl.DataFrame:
        """Descomprime ZIP y parsea CSV contenido usando buffer de bytes."""
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            # Tomar el primer archivo CSV del ZIP
            csv_files = [f for f in zf.namelist() if f.endswith('.csv')]
            if not csv_files:
                raise ValueError("No se encontró archivo CSV en el ZIP")
            
            csv_name = csv_files[0]
            # Leer bytes directamente sin decodificar
            csv_bytes = zf.read(csv_name)
            return parser_func(csv_bytes)
    
    def _parse_kline_csv(self, csv_content: bytes) -> pl.DataFrame:
        """Parsea CSV de klines a DataFrame desde bytes."""
        # Polars lee eficientemente desde BytesIO
        df = pl.read_csv(
            io.BytesIO(csv_content),
            has_header=False,
            new_columns=self.KLINE_COLUMNS,
            schema_overrides={
                "open_time": pl.Int64,
                "open": pl.Utf8,  # Leer como string primero
                "high": pl.Utf8,
                "low": pl.Utf8,
                "close": pl.Utf8,
                "volume": pl.Utf8,
                "close_time": pl.Int64,
                "quote_volume": pl.Utf8,
                "trades_count": pl.Int64,
                "taker_buy_volume": pl.Utf8,
                "taker_buy_quote": pl.Utf8,
                "ignore": pl.Utf8,
            }
        )
        
        return df
    
    def _parse_aggtrade_csv(self, csv_content: bytes) -> pl.DataFrame:
        """Parsea CSV de aggTrades a DataFrame desde bytes."""
        df = pl.read_csv(
            io.BytesIO(csv_content),
            has_header=False,
            new_columns=self.AGGTRADE_COLUMNS,
            schema_overrides={
                "agg_trade_id": pl.Int64,
                "price": pl.Utf8,
                "quantity": pl.Utf8,
                "first_trade_id": pl.Int64,
                "last_trade_id": pl.Int64,
                "timestamp": pl.Int64,
                "is_buyer_maker": pl.Boolean,
                "is_best_match": pl.Boolean,
            }
        )
        
        return df
    
    def _normalize_klines(
        self,
        df: pl.DataFrame,
        start_date: datetime,
        end_date: datetime,
    ) -> pl.DataFrame:
        """
        Normaliza DataFrame de klines al schema estándar fluxica.
        """
        # Convertir timestamp (milisegundos) a nanosegundos Int64
        # Nota: Binance provee milliseconds, multiplicamos por 1_000_000 para obtener nanosegundos
        # df = df.with_columns(
        #     (pl.col("open_time") * 1000).cast(pl.Datetime("us")).dt.replace_time_zone("UTC").cast(pl.Datetime("ns", "UTC")).alias("time")
        # )
        # Mantener time como Int64 (nanosegundos) sin conversión a datetime
        df = df.with_columns(
            (pl.col("open_time") * 1_000_000).alias("time")
        )
        
        # Convertir precios a Float64
        price_cols = ["open", "high", "low", "close"]
        for col in price_cols:
            df = df.with_columns(pl.col(col).cast(pl.Float64))
        
        # Convertir volumen
        df = df.with_columns(
            pl.col("volume").cast(pl.Float64).cast(pl.Int64).alias("volume")
        )
        
        # Seleccionar columnas estándar
        df = df.select(["time", "open", "high", "low", "close", "volume"])
        
        # Filtrar por rango de fechas (convertir a nanosegundos para comparar con Int64)
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)
        
        # Convertir datetime a nanosegundos para comparación
        start_ns = int(start_date.timestamp() * 1_000_000_000)
        end_ns = int(end_date.timestamp() * 1_000_000_000)
        
        # df = df.filter(
        #     (pl.col("time") >= start_date) &
        #     (pl.col("time") <= end_date)
        # )
        df = df.filter(
            (pl.col("time") >= start_ns) &
            (pl.col("time") <= end_ns)
        )
        
        # Eliminar duplicados y ordenar
        df = remove_duplicates(df, subset=["time"])
        df = df.sort("time")
        
        return df
    
    def _normalize_aggtrades(
        self,
        df: pl.DataFrame,
        start_date: datetime,
        end_date: datetime,
        direction_as_sign: bool,
    ) -> pl.DataFrame:
        """Normaliza DataFrame de aggTrades."""
        # Convertir timestamp a nanosegundos Int64
        # Detectar si es ms o us y unificar a nanosegundos
        # Si es menor a 1e14 (100 billones), asumimos ms (válido hasta año 5138)
        # Si es mayor, asumimos us
        # df = df.with_columns(
        #     pl.when(pl.col("timestamp") < 100_000_000_000_000)
        #     .then(pl.col("timestamp") * 1000)
        #     .otherwise(pl.col("timestamp"))
        #     .cast(pl.Datetime("us")).dt.replace_time_zone("UTC").cast(pl.Datetime("ns", "UTC")).alias("time")
        # )
        # Mantener time como Int64 (nanosegundos) sin conversión a datetime
        df = df.with_columns(
            pl.when(pl.col("timestamp") < 100_000_000_000_000)
            .then(pl.col("timestamp") * 1_000_000)  # ms -> ns
            .otherwise(pl.col("timestamp") * 1_000)  # us -> ns
            .alias("time")
        )
        
        # Convertir precios y cantidades
        df = df.with_columns([
            pl.col("price").cast(pl.Float64),
            pl.col("quantity").cast(pl.Float64),
        ])
        
        # Convertir dirección
        if direction_as_sign:
            # is_buyer_maker=True -> venta agresiva (-1)
            # is_buyer_maker=False -> compra agresiva (+1)
            df = df.with_columns(
                pl.when(pl.col("is_buyer_maker"))
                .then(pl.lit(-1))
                .otherwise(pl.lit(1))
                .cast(pl.Int8)
                .alias("direction")
            )
            df = df.drop("is_buyer_maker", "is_best_match")
        else:
            df = df.drop("is_best_match")
        
        # Seleccionar y reordenar columnas
        if direction_as_sign:
            cols = ["time", "agg_trade_id", "price", "quantity", 
                   "first_trade_id", "last_trade_id", "direction"]
        else:
            cols = ["time", "agg_trade_id", "price", "quantity",
                   "first_trade_id", "last_trade_id", "is_buyer_maker"]
        
        df = df.select(cols)
        
        # Filtrar por fechas (convertir a nanosegundos para comparar con Int64)
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)
        
        # Convertir datetime a nanosegundos para comparación
        start_ns = int(start_date.timestamp() * 1_000_000_000)
        end_ns = int(end_date.timestamp() * 1_000_000_000)
        
        # df = df.filter(
        #     (pl.col("time") >= start_date) &
        #     (pl.col("time") <= end_date)
        # )
        df = df.filter(
            (pl.col("time") >= start_ns) &
            (pl.col("time") <= end_ns)
        )
        
        # Ordenar por ID (garantiza orden de llegada al motor)
        df = df.sort("agg_trade_id")
        
        return df
    
    def _empty_kline_dataframe(self) -> pl.DataFrame:
        """Retorna DataFrame vacío con schema de klines."""
        return pl.DataFrame(schema={
            # "time": pl.Datetime("ns", "UTC"),
            # Mantener time como Int64 (nanosegundos)
            "time": pl.Int64,
            "open": pl.Float64,
            "high": pl.Float64,
            "low": pl.Float64,
            "close": pl.Float64,
            "volume": pl.Int64,
        })
    
    def _empty_aggtrade_dataframe(self, direction_as_sign: bool) -> pl.DataFrame:
        """Retorna DataFrame vacío con schema de aggTrades."""
        if direction_as_sign:
            return pl.DataFrame(schema={
                # "time": pl.Datetime("ns", "UTC"),
                # Mantener time como Int64 (nanosegundos)
                "time": pl.Int64,
                "agg_trade_id": pl.Int64,
                "price": pl.Float64,
                "quantity": pl.Float64,
                "first_trade_id": pl.Int64,
                "last_trade_id": pl.Int64,
                "direction": pl.Int8,
            })
        else:
            return pl.DataFrame(schema={
                # "time": pl.Datetime("ns", "UTC"),
                # Mantener time como Int64 (nanosegundos)
                "time": pl.Int64,
                "agg_trade_id": pl.Int64,
                "price": pl.Float64,
                "quantity": pl.Float64,
                "first_trade_id": pl.Int64,
                "last_trade_id": pl.Int64,
                "is_buyer_maker": pl.Boolean,
            })
    
    def get_supported_granularities(self) -> List[str]:
        """Retorna granularidades soportadas para klines."""
        return list(self.GRANULARITY_MAP.keys())
    
    def validate_symbol(self, symbol: str) -> bool:
        """
        Valida si el símbolo existe en Binance.
        
        NOTA: Esta validación tiene latencia de red. Para validar
        múltiples símbolos, considera usar fetch_history con
        manejo de errores.
        """
        symbol = symbol.upper().replace("/", "").replace("-", "")
        
        if not symbol or len(symbol) > 20:
            return False
        
        # Intentar descargar un archivo reciente pequeño
        try:
            yesterday = datetime.now(timezone.utc) - timedelta(days=2)
            url = (
                f"{self.BASE_URL}/{self._base_path}/daily/klines/{symbol}/1d/"
                f"{symbol}-1d-{yesterday.year}-{yesterday.month:02d}-{yesterday.day:02d}.zip"
            )
            response = requests.head(url, timeout=5)
            return response.status_code == 200
        except Exception:
            return False
    
    def validate_agg_trade_continuity(
        self,
        df: pl.DataFrame,
    ) -> Dict[str, any]:
        """
        Valida continuidad de IDs en datos de aggTrades.
        
        La técnica definitiva para detectar pérdida de datos
        es verificar la secuencia de IDs, no los timestamps.
        
        Args:
            df: DataFrame de aggTrades con columna 'agg_trade_id'
            
        Returns:
            Dict con:
            - is_continuous: bool
            - missing_ids: List[int] (primeros 100 IDs faltantes)
            - gap_count: int
            - first_id: int
            - last_id: int
        """
        if df.is_empty() or "agg_trade_id" not in df.columns:
            return {
                "is_continuous": True,
                "missing_ids": [],
                "gap_count": 0,
                "first_id": None,
                "last_id": None,
            }
        
        # Sort by ID to ensure sequence
        df = df.sort("agg_trade_id")
        
        first_id = df["agg_trade_id"].first()
        last_id = df["agg_trade_id"].last()
        
        # Efficient gap detection using Polars expressions
        # Calculate difference between current ID and previous ID
        # Expected diff is 1. If diff > 1, there is a gap.
        
        gap_df = (
            df.lazy()
            .with_columns(
                pl.col("agg_trade_id").shift(1).alias("prev_id")
            )
            .filter(
                (pl.col("agg_trade_id") - pl.col("prev_id")) > 1
            )
            .select([
                "prev_id", 
                "agg_trade_id", 
                (pl.col("agg_trade_id") - pl.col("prev_id") - 1).alias("gap_size")
            ])
            .collect()
        )
        
        gap_count = gap_df["gap_size"].sum() if not gap_df.is_empty() else 0
        
        # Generate sample missing IDs (first 100 max)
        if not gap_df.is_empty():
            # Flattened list comprehension to get missing IDs
            # Limit to 100 items total effectively
            all_missing = [
                i 
                for row in gap_df.iter_rows(named=True) 
                for i in range(row["prev_id"] + 1, row["agg_trade_id"])
            ]
            missing_ids = all_missing[:100]
        else:
            missing_ids = []
        
        return {
            "is_continuous": (gap_count == 0) and ( (last_id - first_id + 1) == len(df) ),
            "missing_ids": missing_ids,
            "gap_count": gap_count,
            "first_id": first_id,
            "last_id": last_id,
        }