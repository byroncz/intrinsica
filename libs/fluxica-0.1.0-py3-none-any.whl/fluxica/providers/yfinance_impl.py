# src/fluxica/providers/yfinance_impl.py

import yfinance as yf
import polars as pl
from datetime import datetime, timezone
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..interfaces import DataProvider
from ..utils import (
    normalize_ohlcv_names,
    normalize_timezone_to_utc,
    ensure_float64_prices,
    ensure_int64_volume,
    handle_missing_values,
    remove_duplicates,
)


class YFinanceProvider(DataProvider):
    """
    Proveedor de datos para Yahoo Finance.
    
    Soporta: Acciones, ETFs, Índices, Futuros, Crypto.
    
    Limitaciones conocidas:
    - Datos intradía (1m, 5m, etc.) limitados a últimos 7-60 días
    - Para historia larga (años), solo granularidad diaria (1d) o superior
    - Rate limiting no documentado oficialmente
    - Bug de memoria compartida con hilos (mitigado con instancias aisladas)
    """
    
    # Granularidades soportadas por Yahoo
    GRANULARITIES = [
        "1m", "2m", "5m", "15m", "30m", "60m", "90m", 
        "1h", "1d", "5d", "1wk", "1mo", "3mo"
    ]
    
    # Workers por defecto para descargas paralelas
    # 4-8 es rango seguro para no saturar CPU ni disparar alertas en Yahoo
    DEFAULT_MAX_WORKERS = 8
    
    def __init__(self, max_workers: int = DEFAULT_MAX_WORKERS):
        """
        Inicializa el provider.
        
        Args:
            max_workers: Número máximo de hilos para descargas paralelas.
                        Rango recomendado: 4-8. Default: 8.
        
        No requiere autenticación para datos públicos.
        """
        self.max_workers = max(1, min(max_workers, 16))  # Limitar entre 1 y 16
    
    def fetch_history(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        granularity: str = "1d"
    ) -> pl.DataFrame:
        """
        Descarga datos históricos de Yahoo Finance para UN símbolo.
        
        IMPORTANTE: Para granularidades < 1d, Yahoo solo retorna
        datos recientes (7-60 días dependiendo de la granularidad).
        
        Args:
            symbol: Ticker del activo (ej: "AAPL", "MSFT")
            start_date: Fecha inicial
            end_date: Fecha final
            granularity: Resolución temporal (default: "1d")
            
        Returns:
            DataFrame de Polars con schema estandarizado
        """
        # Validaciones
        if granularity not in self.GRANULARITIES:
            raise ValueError(
                f"Granularidad '{granularity}' no soportada. "
                f"Opciones: {self.GRANULARITIES}"
            )
        
        # Formatear fechas
        start_str = start_date.strftime("%Y-%m-%d")
        end_str = end_date.strftime("%Y-%m-%d")
        
        # Descarga con instancia AISLADA (evita bug de shared._DFS)
        ticker = yf.Ticker(symbol)
        
        try:
            pdf = ticker.history(
                start=start_str,
                end=end_str,
                interval=granularity,
                auto_adjust=True,   # Ajusta splits y dividendos
                actions=False,      # No incluir dividendos/splits como filas
            )
        except Exception as e:
            raise ConnectionError(f"Error descargando {symbol}: {e}")
        
        if pdf.empty:
            return self._empty_dataframe()
        
        # CONVERSIÓN INMEDIATA A POLARS
        pdf = pdf.reset_index()
        df = pl.from_pandas(pdf)
        
        # Pipeline de normalización
        df = self._normalize(df)
        
        # Validar schema de salida
        self._validate_output_schema(df)
        
        return df
    
    def fetch_multiple_tickers(
        self,
        symbols: List[str],
        start_date: datetime,
        end_date: datetime,
        granularity: str = "1d",
        max_workers: Optional[int] = None,
        on_error: str = "skip"
    ) -> Dict[str, pl.DataFrame]:
        """
        Descarga datos históricos para MÚLTIPLES símbolos en paralelo.
        
        Usa ThreadPoolExecutor con instancias aisladas de yf.Ticker
        para evitar el bug de memoria compartida (shared._DFS).
        
        Cada hilo crea su propia instancia de yf.Ticker, garantizando
        aislamiento de estado y evitando race conditions.
        
        Args:
            symbols: Lista de tickers (ej: ["AAPL", "MSFT", "GOOGL"])
            start_date: Fecha inicial (inclusive)
            end_date: Fecha final (inclusive)
            granularity: Resolución temporal (default: "1d")
            max_workers: Hilos máximos. Si None, usa self.max_workers.
                        Se ajusta automáticamente a no exceder len(symbols).
            on_error: Comportamiento ante errores por ticker:
                - "skip": Ignora ticker fallido, continúa con otros (default)
                - "raise": Lanza excepción al primer error
                
        Returns:
            Dict[str, pl.DataFrame]: Diccionario {ticker: DataFrame}.
            Tickers fallidos se omiten si on_error="skip".
            DataFrames vacíos también se omiten.
            
        Raises:
            ValueError: Si granularidad no es válida
            Exception: Si on_error="raise" y algún ticker falla
            
        Example:
            >>> provider = YFinanceProvider()
            >>> from datetime import datetime
            >>> 
            >>> dfs = provider.fetch_multiple_tickers(
            ...     symbols=["AAPL", "MSFT", "GOOGL", "AMZN"],
            ...     start_date=datetime(2020, 1, 1),
            ...     end_date=datetime(2024, 1, 1),
            ...     granularity="1d"
            ... )
            >>> 
            >>> print(f"Descargados: {list(dfs.keys())}")
            Descargados: ['AAPL', 'MSFT', 'GOOGL', 'AMZN']
            >>> 
            >>> # Cada DataFrame tiene el schema estándar
            >>> print(dfs["AAPL"].columns)
            ['time', 'open', 'high', 'low', 'close', 'volume']
        
        Performance:
            - 10 tickers con 8 workers: ~3-5 segundos (vs ~15-20 secuencial)
            - 50 tickers con 8 workers: ~15-25 segundos (vs ~75-100 secuencial)
        """
        if not symbols:
            return {}
        
        # Eliminar duplicados preservando orden
        symbols = list(dict.fromkeys(symbols))
        
        # Validar granularidad una sola vez (antes de crear hilos)
        if granularity not in self.GRANULARITIES:
            raise ValueError(
                f"Granularidad '{granularity}' no soportada. "
                f"Opciones: {self.GRANULARITIES}"
            )
        
        # Determinar número de workers
        workers = max_workers if max_workers is not None else self.max_workers
        workers = max(1, min(workers, len(symbols)))  # No más workers que símbolos
        
        results: Dict[str, pl.DataFrame] = {}
        errors: Dict[str, str] = {}
        
        def _worker_fetch(symbol: str) -> tuple[str, Optional[pl.DataFrame], Optional[str]]:
            """
            Función worker que se ejecuta en cada hilo.
            
            Crea instancia AISLADA de yf.Ticker para evitar
            el bug de shared._DFS documentado en el PDF.
            
            Returns:
                Tupla (symbol, dataframe_o_none, error_msg_o_none)
            """
            try:
                df = self.fetch_history(symbol, start_date, end_date, granularity)
                return (symbol, df, None)
            except Exception as e:
                return (symbol, None, str(e))
        
        # Ejecutar descargas en paralelo con ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=workers) as executor:
            # Mapear futures a símbolos para tracking
            future_to_symbol = {
                executor.submit(_worker_fetch, sym): sym
                for sym in symbols
            }
            
            # Recolectar resultados conforme terminan (no en orden de submit)
            for future in as_completed(future_to_symbol):
                symbol = future_to_symbol[future]
                
                try:
                    res_symbol, df, error_msg = future.result()
                    
                    if error_msg is not None:
                        # Error en la descarga
                        if on_error == "raise":
                            raise ConnectionError(f"Error en {res_symbol}: {error_msg}")
                        errors[res_symbol] = error_msg
                        
                    elif df is not None and not df.is_empty():
                        # Descarga exitosa con datos
                        results[res_symbol] = df
                    # Si df está vacío, simplemente no lo agregamos
                        
                except Exception as e:
                    # Error inesperado del future
                    if on_error == "raise":
                        raise
                    errors[symbol] = str(e)
        
        # Reportar errores si los hubo
        if errors:
            failed_list = list(errors.keys())
            print(f"[YFinanceProvider] {len(failed_list)} ticker(s) fallaron: {failed_list}")
        
        return results
    
    def _normalize(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Pipeline de normalización para datos de Yahoo.
        
        Transforma el DataFrame crudo de pandas/yfinance
        al schema estandarizado de fluxica.
        """
        # 1. Nombres de columnas a minúsculas y estándar
        df = normalize_ohlcv_names(df)
        
        # 2. Timezone a UTC
        df = normalize_timezone_to_utc(df, "time")
        
        # 3. Tipos de datos correctos
        df = ensure_float64_prices(df)
        df = ensure_int64_volume(df)
        
        # 4. Limpieza básica
        df = remove_duplicates(df, subset=["time"])
        df = handle_missing_values(df)
        
        # 5. Seleccionar y ordenar columnas estándar
        standard_cols = ["time", "open", "high", "low", "close", "volume"]
        existing = [c for c in standard_cols if c in df.columns]
        
        # Asegurar precisión ns para cumplir contrato de interface
        df = df.with_columns(pl.col("time").cast(pl.Datetime("ns", "UTC")))
        
        return df.select(existing).sort("time")
    
    def _empty_dataframe(self) -> pl.DataFrame:
        """Retorna DataFrame vacío con schema correcto."""
        return pl.DataFrame(schema={
            "time": pl.Datetime("ns", "UTC"),
            "open": pl.Float64,
            "high": pl.Float64,
            "low": pl.Float64,
            "close": pl.Float64,
            "volume": pl.Int64,
        })
    
    def get_supported_granularities(self) -> List[str]:
        """Retorna granularidades soportadas por Yahoo Finance."""
        return self.GRANULARITIES.copy()
    
    def validate_symbol(self, symbol: str) -> bool:
        """
        Valida si el símbolo existe en Yahoo Finance.
        
        ADVERTENCIA: Esta operación tiene latencia de red (~200-500ms).
        Para validar múltiples símbolos, considera usar fetch_multiple_tickers
        con on_error="skip" y verificar qué tickers retornaron datos.
        
        Args:
            symbol: Ticker a validar (ej: "AAPL")
            
        Returns:
            True si el símbolo es válido y tiene datos
        """
        if not symbol or not isinstance(symbol, str):
            return False
        
        symbol = symbol.strip().upper()
        
        if len(symbol) > 10:
            return False
        
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            return info.get("regularMarketPrice") is not None
        except Exception:
            return False