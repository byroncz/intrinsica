# src/fluxica/factory.py

from typing import Dict, Type, Optional, Any

from .interfaces import DataProvider
from .providers.yfinance_impl import YFinanceProvider
from .providers.binance_impl import BinanceVisionProvider
# Importaciones futuras:
# from .providers.oanda_impl import OandaProvider
# from .providers.fred_impl import FredProvider


class ProviderFactory:
    """
    Factory para crear instancias de proveedores de datos.
    
    Centraliza la lógica de creación, configuración y validación.
    El cliente NO debe instanciar proveedores directamente.
    
    Uso:
        >>> from fluxica import ProviderFactory
        >>> yahoo = ProviderFactory.create("yahoo")
        >>> df = yahoo.fetch_history("AAPL", start, end)
        >>> 
        >>> # Binance Vision para crypto
        >>> binance = ProviderFactory.create("binance_vision")
        >>> df = binance.fetch_history("BTCUSDT", start, end)
    """
    
    # Registro de proveedores disponibles
    _registry: Dict[str, Type[DataProvider]] = {
        "yahoo": YFinanceProvider,
        "binance_vision": BinanceVisionProvider,
        # "oanda": OandaProvider,  # Requiere api_token
        # "fred": FredProvider,    # Requiere api_key
    }
    
    @classmethod
    def create(cls, provider_name: str, **kwargs: Any) -> DataProvider:
        """
        Crea una instancia del proveedor solicitado.
        
        Args:
            provider_name: Nombre del proveedor:
                - "yahoo": Acciones, ETFs, Índices
                - "binance_vision": Crypto (Binance historical data)
                - "oanda": Forex (próximamente)
                - "fred": Datos macro (próximamente)
            **kwargs: Argumentos específicos del proveedor:
                - binance_vision: market_type, max_workers, verify_checksum
                - oanda: api_token, environment
                - fred: api_key
                - yahoo: max_workers
        
        Returns:
            Instancia del proveedor solicitado
            
        Raises:
            ValueError: Si el proveedor no existe en el registro
            TypeError: Si faltan argumentos requeridos
            
        Example:
            >>> yahoo = ProviderFactory.create("yahoo")
            >>> binance = ProviderFactory.create("binance_vision", market_type="spot")
            >>> binance_futures = ProviderFactory.create("binance_vision", market_type="futures_um")
        """
        provider_name = provider_name.lower().strip()
        
        if provider_name not in cls._registry:
            available = list(cls._registry.keys())
            raise ValueError(
                f"Proveedor '{provider_name}' no registrado. "
                f"Disponibles: {available}"
            )
        
        provider_class = cls._registry[provider_name]
        
        try:
            return provider_class(**kwargs)
        except TypeError as e:
            raise TypeError(
                f"Error creando '{provider_name}': {e}. "
                f"Revisa los argumentos requeridos."
            )
    
    @classmethod
    def register(cls, name: str, provider_class: Type[DataProvider]) -> None:
        """
        Registra un nuevo proveedor en tiempo de ejecución.
        
        Útil para extender fluxica con proveedores personalizados
        sin modificar el código fuente.
        
        Args:
            name: Identificador del proveedor
            provider_class: Clase que hereda de DataProvider
            
        Raises:
            TypeError: Si provider_class no hereda de DataProvider
            
        Example:
            >>> class MyCustomProvider(DataProvider):
            ...     # implementación
            >>> ProviderFactory.register("custom", MyCustomProvider)
        """
        if not issubclass(provider_class, DataProvider):
            raise TypeError(
                f"'{provider_class.__name__}' debe heredar de DataProvider"
            )
        
        cls._registry[name.lower().strip()] = provider_class
    
    @classmethod
    def list_providers(cls) -> list[str]:
        """
        Lista todos los proveedores registrados.
        
        Returns:
            Lista de nombres de proveedores disponibles
        """
        return list(cls._registry.keys())
    
    @classmethod
    def is_registered(cls, name: str) -> bool:
        """
        Verifica si un proveedor está registrado.
        
        Args:
            name: Nombre del proveedor
            
        Returns:
            True si existe, False en caso contrario
        """
        return name.lower().strip() in cls._registry