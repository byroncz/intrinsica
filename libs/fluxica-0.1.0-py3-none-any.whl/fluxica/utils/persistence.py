# src/fluxica/utils/persistence.py
"""
Módulo de persistencia para datos financieros usando patrón DuckLake.

Arquitectura:
    - Motor de Ingesta/Consulta: DuckDB
    - Catálogo de Metadatos: SQLite (catalog.db)
    - Almacenamiento: Archivos Parquet particionados (Hive-style)

Estructura de particiones:
    - Todas las granularidades: ticker/provider/granularity/year/month
"""

import shutil
import sqlite3
import duckdb
import os
import glob
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Literal, Union, Dict, Any, List

import polars as pl
from rich.console import Console

# Granularidades consideradas "intradía" (menores a 1 hora)
INTRADAY_GRANULARITIES = frozenset([
    "1m", "2m", "5m", "15m", "30m",
    "M1", "M2", "M5", "M15", "M30",
    "tick",
])

class PartitionManager:
    """
    Gestor de persistencia DuckLake (DuckDB + SQLite).
    """
    
    def __init__(self, base_path: Union[str, Path]):
        """
        Inicializa el gestor con un directorio base y conecta al catálogo.
        
        Args:
            base_path: Directorio raíz para datos y catálogo.
        """
        self.base_path = Path(base_path)
        
        # Estructura Datalake: storage/ para datos, catalog/ para metadatos
        self.storage_path = self.base_path / "storage"
        self.catalog_path = self.base_path / "catalog"
        
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.catalog_path.mkdir(parents=True, exist_ok=True)
        
        self.db_path = self.catalog_path / "catalog.db"
        self._init_catalog()
        
        # Conexión volátil a DuckDB para operaciones de I/O
        self.duck = duckdb.connect()

    def _init_catalog(self):
        """Inicializa el esquema de SQLite si no existe."""
        with sqlite3.connect(self.db_path) as conn:
            # Migration support
            try:
                conn.execute("ALTER TABLE partitions ADD COLUMN size_bytes INTEGER")
            except sqlite3.OperationalError:
                pass
            
            # Migration: Add day column for day-level partitioning
            try:
                conn.execute("ALTER TABLE partitions ADD COLUMN day INTEGER")
            except sqlite3.OperationalError:
                pass

            conn.execute("""
                CREATE TABLE IF NOT EXISTS partitions (
                    file_path TEXT PRIMARY KEY,
                    ticker TEXT,
                    provider TEXT,
                    granularity TEXT,
                    year INTEGER,
                    month INTEGER,
                    day INTEGER,
                    row_count INTEGER,
                    size_bytes INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ticker ON partitions(ticker)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_provider ON partitions(provider)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_granularity ON partitions(granularity)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time ON partitions(year, month)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_day ON partitions(day)")

    def _is_intraday_granularity(self, granularity: str) -> bool:
        return granularity.lower() in {g.lower() for g in INTRADAY_GRANULARITIES}

    def _build_partition_path(
        self,
        ticker: str,
        provider: str,
        granularity: str,
        year: int,
        month: int,
        day: Optional[int] = None,
    ) -> Path:
        """
        Reconstruye la ruta teórica de una partición (Utility/Legacy).
        Nota: DuckDB genera nombres de archivo aleatorios, esto solo predice el directorio.
        
        Args:
            day: Si se especifica, incluye day=DD en la ruta para particiones diarias.
        """
        path = self.storage_path / f"ticker={ticker}"
        path = path / f"provider={provider}"
        path = path / f"granularity={granularity}"
        path = path / f"year={year:04d}"
        path = path / f"month={month:02d}"
        if day is not None:
            path = path / f"day={day:02d}"
        
        return path

    def _create_partition_record(self, file_path: Path, known_meta: Optional[Dict[str, Any]] = None) -> Optional[tuple]:
        """Helper to create a partition record tuple."""
        try:
            parts = file_path.parts
            meta = known_meta.copy() if known_meta else {}
            
            # Parse Hive parts from path if not in known_meta or to supplement it
            for part in parts:
                if "=" in part:
                    k, v = part.split("=", 1)
                    # For rebuild_catalog, we need to parse everything
                    if k in ("ticker", "provider", "granularity") and k not in meta:
                        meta[k] = v
                    elif k in ("year", "month", "day"):
                        try:
                            meta[k] = int(v)
                        except ValueError:
                            pass
            
            # Validation for rebuild_catalog case
            if "ticker" not in meta or "provider" not in meta:
                return None

            # Metadata
            try:
                size = file_path.stat().st_size
            except FileNotFoundError:
                return None

            count = 0
            try:
                count = self.duck.execute(f"SELECT count(*) FROM read_parquet('{str(file_path)}')").fetchone()[0]
            except Exception:
                pass
            
            return (
                str(file_path),
                meta.get("ticker"),
                meta.get("provider"),
                meta.get("granularity", "unknown"),
                meta.get("year"),
                meta.get("month"),
                meta.get("day"),  # Can be None for monthly partitions
                count,
                size
            )
        except Exception as e:
            # Silent fail or log? equivalent to original try/except blocks
            return None

    def _handle_legacy_renaming(self, p: str) -> str:
        """Renames file to data.parquet if it is the only file in the directory (Legacy compatibility)."""
        try:
            p_obj = Path(p)
            # Si el archivo no es data.parquet y está en la carpeta de la partición...
            if p_obj.name != "data.parquet":
                # Chequear si es el único parquet en el dir
                if len(list(p_obj.parent.glob("*.parquet"))) == 1:
                    new_path = p_obj.parent / "data.parquet"
                    p_obj.rename(new_path)
                    
                    # Actualizar catálogo
                    with sqlite3.connect(self.db_path) as conn:
                            conn.execute("UPDATE partitions SET file_path=? WHERE file_path=?", (str(new_path), str(p)))
                            
                    return str(new_path)
        except Exception:
            pass
        return p

    def _update_catalog_from_write(self, ticker: str, provider: str, granularity: str) -> List[str]:
        """Escanea el directorio específico y actualiza el catálogo. Retorna paths encontrados."""
        series_path = self.storage_path / f"ticker={ticker}/provider={provider}/granularity={granularity}"
        if not series_path.exists():
            return []

        files = list(series_path.glob("**/*.parquet"))
        
        # Base metadata provided by caller
        base_meta = {
            "ticker": ticker,
            "provider": provider,
            "granularity": granularity,
        }

        # Process all files
        # We need both the row for insertion and the path for returning
        # _create_partition_record returns the row tuple. The first element is the file path.
        results = [self._create_partition_record(f, base_meta) for f in files]
        rows_to_insert = [r for r in results if r is not None]
        found_paths = [r[0] for r in rows_to_insert]

        if rows_to_insert:
            with sqlite3.connect(self.db_path) as conn:
                conn.executemany("""
                    INSERT OR REPLACE INTO partitions 
                    (file_path, ticker, provider, granularity, year, month, day, row_count, size_bytes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, rows_to_insert)
                
        return found_paths

    def write(
        self,
        df: pl.DataFrame,
        ticker: str,
        provider: str,
        granularity: str = "tick",
        time_col: str = "time",
        compression: Literal["snappy", "gzip", "lz4", "zstd", "uncompressed"] = "snappy",
        overwrite: bool = True,
        partition_by_day: bool = False,
    ) -> Dict[str, Any]:
        """
        Escribe DataFrame usando DuckDB COPY.
        
        Args:
            partition_by_day: Si True, particiona también por día (day=DD).
                             Usar para datos del mes actual que se ingestarán
                             incrementalmente y luego se compactarán.
        """
        if df.is_empty():
            raise ValueError("DataFrame vacío: nada que escribir")
        if time_col not in df.columns:
            raise ValueError(f"Columna temporal '{time_col}' no encontrada")
        
        # Check constraints (Legacy behavior)
        if not overwrite:
            dates = df.select(
                pl.col(time_col).dt.year().alias("year"),
                pl.col(time_col).dt.month().alias("month")
            ).unique()
            
            for row in dates.rows(named=True):
                query = "SELECT count(*) FROM partitions WHERE ticker=? AND provider=? AND granularity=? AND year=? AND month=?"
                params = [ticker, provider, granularity, int(row["year"]), int(row["month"])]
                
                with sqlite3.connect(self.db_path) as conn:
                    exists = conn.execute(query, params).fetchone()[0] > 0
                    
                if exists:
                     raise FileExistsError(f"Partición ya existe para {row['year']}-{row['month']}")
        else:
            # Pre-limpieza para garantizar Overwrite real con DuckDB COPY
            # Borramos particiones completas de Año/Mes detectadas en el DF
            if partition_by_day:
                # Para partición por día, borrar solo los días específicos
                dates = df.select(
                    pl.col(time_col).dt.year().alias("year"),
                    pl.col(time_col).dt.month().alias("month"),
                    pl.col(time_col).dt.day().alias("day")
                ).unique()
                
                for row in dates.rows(named=True):
                    self.delete(
                        ticker, provider, granularity, 
                        int(row["year"]), int(row["month"]),
                        day=int(row["day"]),
                        confirm=True
                    )
            else:
                dates = df.select(
                    pl.col(time_col).dt.year().alias("year"),
                    pl.col(time_col).dt.month().alias("month")
                ).unique()
                
                for row in dates.rows(named=True):
                     self.delete(
                         ticker, provider, granularity, 
                         int(row["year"]), int(row["month"]), 
                         confirm=True
                     )

        # Preparar columnas con Padding para matching de estructura Hive legacy
        base_columns = [
            pl.lit(ticker).alias("ticker"),
            pl.lit(provider).alias("provider"),
            pl.lit(granularity).alias("granularity"),
            
            # Cast a string con padding
            pl.col(time_col).dt.year().cast(pl.Utf8).alias("year"),
            pl.col(time_col).dt.month().cast(pl.Utf8).str.zfill(2).alias("month"),
            
            # INTERNAL: Cast to Int64 (ns) to bypass DuckDB Microsecond truncation
            # Must cast to Datetime("ns") first to ensure we get nanoseconds, not micro/milliseconds
            pl.col(time_col).cast(pl.Datetime("ns")).cast(pl.Int64).alias("__time_ns__")
        ]
        
        if partition_by_day:
            base_columns.append(
                pl.col(time_col).dt.day().cast(pl.Utf8).str.zfill(2).alias("day")
            )
            partition_cols = ["ticker", "provider", "granularity", "year", "month", "day"]
        else:
            partition_cols = ["ticker", "provider", "granularity", "year", "month"]
        
        df_export = df.with_columns(base_columns)
        
        table_name = f"ingest_{ticker}_{provider}_{int(datetime.now().timestamp())}"
        self.duck.register(table_name, df_export)
        
        output_path = str(self.storage_path)
        
        try:
            # COPY with explicit TIMESTAMP_NS cast
            # We filter out the original fractional timestamp and the temp int64 column,
            # then reconstruct the timestamp using make_timestamp_ns to ensure NANOS unit in Parquet.
            cols_except_time = [c for c in df_export.columns if c not in (time_col, "__time_ns__")]
            cols_select = ", ".join(cols_except_time)
            
            query = f"""
            COPY (
                SELECT 
                    {cols_select},
                    make_timestamp_ns(__time_ns__) AS {time_col}
                FROM {table_name}
                ORDER BY {time_col} ASC
            ) 
            TO '{output_path}' 
            (FORMAT PARQUET, PARTITION_BY ({', '.join(partition_cols)}), COMPRESSION '{compression.upper()}', OVERWRITE_OR_IGNORE 1)
            """
            self.duck.execute(query)
            
            # Sincronizar
            paths = self._update_catalog_from_write(ticker, provider, granularity)
            
            # DuckDB genera nombres como data_0.parquet. 
            # Si queremos ser 100% legacy compatible con "data.parquet", tendríamos que renombrar si es un solo archivo.
            # Los tests buscan "path/to/data.parquet".
            # Haremos un esfuerzo de renombrado si hay 1 solo archivo por carpeta hoja.
            
            renamed_paths = [self._handle_legacy_renaming(p) for p in paths]

            return {
                "partitions_written": len(renamed_paths),
                "rows_written": len(df),
                "paths": renamed_paths
            }
            
        except Exception as e:
            raise RuntimeError(f"Error en DuckDB COPY: {e}")
        finally:
            self.duck.unregister(table_name)

    def read(
        self,
        ticker: Optional[str] = None,
        provider: Optional[str] = None,
        granularity: Optional[str] = None,
        year: Optional[int] = None,
        month: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> pl.DataFrame:
        """Lee datos consultando el catálogo SQLite y cargando con DuckDB."""
        if not self.db_path.exists():
            return pl.DataFrame()

        query = "SELECT file_path FROM partitions WHERE 1=1"
        params = []
        
        if ticker:
            query += " AND ticker = ?"
            params.append(ticker)
        if provider:
            query += " AND provider = ?"
            params.append(provider)
        if granularity:
            query += " AND granularity = ?"
            params.append(granularity)
        if year:
            query += " AND year = ?"
            params.append(year)
        if month:
            query += " AND month = ?"
            params.append(month)

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(query, params)
            files = [row[0] for row in cursor.fetchall()]

        if not files:
            return pl.DataFrame()
        
        # Validar consistencia de timezone
        if start_date and start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if end_date and end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)

        try:
            files_sql = ", ".join([f"'{f}'" for f in files])
            read_query = f"SELECT * FROM read_parquet([{files_sql}], hive_partitioning=1)"
            
            conditions = []
            if start_date:
                conditions.append(f"time >= '{start_date.isoformat()}'")
            if end_date:
                conditions.append(f"time <= '{end_date.isoformat()}'")
                
            if conditions:
                read_query += " WHERE " + " AND ".join(conditions)
                
            read_query += " ORDER BY time ASC"
            
            res = self.duck.sql(read_query).pl()
            
            # Rehydrate UTC timezone for application consistency
            # TIMESTAMP_NS is naive-in-metadata but physically UTC
            if "time" in res.columns:
                 res = res.with_columns(pl.col("time").dt.replace_time_zone("UTC"))
                 
            return res
            
        except Exception as e:
            df = pl.read_parquet(files)
            if start_date:
                df = df.filter(pl.col("time") >= start_date)
            if end_date:
                df = df.filter(pl.col("time") <= end_date)
            
            df = df.sort("time")
            
            # Rehydrate UTC timezone
            if "time" in df.columns:
                 df = df.with_columns(pl.col("time").dt.replace_time_zone("UTC"))
                 
            return df

    def list_partitions(
        self,
        ticker: Optional[str] = None,
        provider: Optional[str] = None,
        granularity: Optional[str] = None,
    ) -> pl.DataFrame:
        """Lista particiones desde el catálogo."""
        if not self.db_path.exists():
            return pl.DataFrame()

        query = "SELECT * FROM partitions WHERE 1=1"
        params = []
        
        if ticker:
            query += " AND ticker = ?"
            params.append(ticker)
        if provider:
            query += " AND provider = ?"
            params.append(provider)
        if granularity:
            query += " AND granularity = ?"
            params.append(granularity)

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(query, params)
            if cursor.description is None:
                 return pl.DataFrame()
            columns = [d[0] for d in cursor.description]
            data = cursor.fetchall()
            
        return pl.DataFrame(data, schema=columns, orient="row")

    def rebuild_catalog(self):
        """Reconstruye el catálogo escaneando todo el sistema de archivos."""
        console = Console()
        console.print("[yellow]Reconstruyendo catálogo DuckLake...[/yellow]")
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM partitions")
        
        files = list(self.storage_path.glob("**/ticker=*/provider=*/**/*.parquet"))
        
        results = [self._create_partition_record(f) for f in files]
        rows = [r for r in results if r is not None]

        if rows:
            with sqlite3.connect(self.db_path) as conn:
                conn.executemany("""
                    INSERT INTO partitions 
                    (file_path, ticker, provider, granularity, year, month, day, row_count, size_bytes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, rows)
        
        console.print(f"[green]Catálogo reconstruido. {len(rows)} particiones indexadas.[/green]")

    def delete(
        self,
        ticker: str,
        provider: str,
        granularity: str,
        year: int,
        month: int,
        day: Optional[int] = None,
        confirm: bool = False,
    ) -> bool:
        """
        Elimina particiones físicas y del catálogo.
        
        Args:
            day: Si se especifica, elimina solo la partición de ese día.
                 Si es None, elimina todas las particiones del mes.
        """
        if not confirm:
            raise ValueError("Debe pasar confirm=True para eliminar particiones.")
            
        files_df = self.list_partitions(ticker, provider, granularity)
        if files_df.is_empty():
             return False

        # Filtrar por año y mes
        files_df = files_df.filter(
            (pl.col("year") == year) & 
            (pl.col("month") == month) 
        )
        
        # Filtrar por día si se especifica
        if day is not None:
            files_df = files_df.filter(pl.col("day") == day)
        
        if files_df.is_empty():
            return False

        deleted_count = 0
        for p in files_df["file_path"]:
            try:
                file_path = Path(p)
                file_path.unlink()
                deleted_count += 1
                
                # Limpiar directorios vacíos hacia arriba
                parent = file_path.parent
                while parent != self.storage_path:
                    try:
                        if not any(parent.iterdir()):
                            parent.rmdir()
                            parent = parent.parent
                        else:
                            break
                    except OSError:
                        break
            except OSError:
                pass
                
        with sqlite3.connect(self.db_path) as conn:
            if day is not None:
                query = """
                    DELETE FROM partitions 
                    WHERE ticker=? AND provider=? AND granularity=? 
                    AND year=? AND month=? AND day=?
                """
                params = [ticker, provider, granularity, year, month, day]
            else:
                query = """
                    DELETE FROM partitions 
                    WHERE ticker=? AND provider=? AND granularity=? 
                    AND year=? AND month=?
                """
                params = [ticker, provider, granularity, year, month]
                
            conn.execute(query, params)
        
        return deleted_count > 0
    
    def compact_month(
        self,
        ticker: str,
        provider: str,
        granularity: str,
        year: int,
        month: int,
        confirm: bool = False,
    ) -> Dict[str, Any]:
        """
        Compacta particiones diarias en un único archivo mensual.
        
        Lee todas las particiones diarias del mes especificado,
        las consolida en un solo archivo mensual, y elimina las
        particiones diarias originales.
        
        Args:
            ticker, provider, granularity: Identificadores de la serie
            year, month: Mes a compactar
            confirm: Debe ser True para ejecutar (protección)
        
        Returns:
            Dict con estadísticas: days_compacted, rows_total, path
        """
        if not confirm:
            raise ValueError("Debe pasar confirm=True para compactar")
        
        # 1. Identificar particiones diarias del mes
        partitions_df = self.list_partitions(ticker, provider, granularity)
        if partitions_df.is_empty():
            return {"days_compacted": 0, "rows_total": 0, "path": None}
        
        day_partitions = partitions_df.filter(
            (pl.col("year") == year) & 
            (pl.col("month") == month) & 
            (pl.col("day").is_not_null())
        )
        
        days_count = len(day_partitions)
        if days_count == 0:
            return {"days_compacted": 0, "rows_total": 0, "path": None}
        
        # 2. Leer todas las particiones del mes (incluye diarias)
        df = self.read(ticker, provider, granularity, year, month)
        
        if df.is_empty():
            return {"days_compacted": 0, "rows_total": 0, "path": None}
        
        # 3. Eliminar particiones diarias
        for row in day_partitions.rows(named=True):
            self.delete(
                ticker, provider, granularity,
                year, month, day=row["day"],
                confirm=True
            )
        
        # 4. Escribir como partición mensual (sin day)
        result = self.write(
            df, ticker, provider, granularity,
            partition_by_day=False,
            overwrite=True
        )
        
        return {
            "days_compacted": days_count,
            "rows_total": len(df),
            "path": result["paths"][0] if result["paths"] else None
        }

    def consolidate_from_source(
        self,
        ticker: str,
        provider: str,
        granularity: str,
        year: int,
        month: int,
        data_type: Literal["klines", "agg_trades"] = "agg_trades",
        confirm: bool = False,
    ) -> Dict[str, Any]:
        """
        Consolida particiones re-descargando datos del proveedor original.
        
        A diferencia de compact_month() que solo combina particiones existentes,
        este método:
        1. Elimina TODAS las particiones del mes (diarias Y mensuales)
        2. Re-descarga datos del proveedor original (Binance Vision)
        3. Escribe como partición mensual única
        
        Esto garantiza que se obtienen datos corregidos si el proveedor
        hizo actualizaciones post-publicación.
        
        Args:
            ticker: Símbolo del activo (ej: "BTCUSDT")
            provider: Proveedor de datos. Actualmente solo soporta "binance_vision"
            granularity: Granularidad de los datos (ej: "tick", "1m", "1d")
            year: Año a consolidar
            month: Mes a consolidar (1-12)
            data_type: Tipo de datos a descargar:
                - "klines": Velas OHLCV
                - "agg_trades": Operaciones agregadas (tick data)
            confirm: Debe ser True para ejecutar (protección)
        
        Returns:
            Dict con estadísticas: {
                "partitions_deleted": int,
                "rows_downloaded": int,
                "path": str (ruta de la nueva partición)
            }
        
        Raises:
            ValueError: Si confirm=False o proveedor no soportado
            RuntimeError: Si falla la descarga del proveedor
        
        Example:
            >>> from fluxica.utils import PartitionManager
            >>> manager = PartitionManager("/path/to/datalake")
            >>> result = manager.consolidate_from_source(
            ...     ticker="BTCUSDT",
            ...     provider="binance_vision",
            ...     granularity="tick",
            ...     year=2024,
            ...     month=12,
            ...     data_type="agg_trades",
            ...     confirm=True
            ... )
        """
        if not confirm:
            raise ValueError("Debe pasar confirm=True para consolidar desde origen")
        
        # Validar proveedor soportado
        supported_providers = ["binance_vision"]
        if provider not in supported_providers:
            raise ValueError(
                f"Proveedor '{provider}' no soportado para consolidate_from_source. "
                f"Soportados: {supported_providers}"
            )
        
        console = Console()
        console.print(f"[bold cyan]Consolidando {ticker} {year}-{month:02d} desde {provider}...[/bold cyan]")
        
        # 1. Contar y eliminar particiones existentes del mes
        partitions_df = self.list_partitions(ticker, provider, granularity)
        partitions_to_delete = partitions_df.filter(
            (pl.col("year") == year) & 
            (pl.col("month") == month)
        )
        
        partitions_deleted = len(partitions_to_delete)
        
        if partitions_deleted > 0:
            console.print(f"[yellow]Eliminando {partitions_deleted} particiones existentes...[/yellow]")
            
            # Eliminar todas las particiones del mes (diarias y mensuales)
            for row in partitions_to_delete.rows(named=True):
                day_val = row.get("day")
                self.delete(
                    ticker, provider, granularity,
                    year, month, day=day_val,
                    confirm=True
                )
        
        # 2. Re-descargar del proveedor original
        console.print(f"[cyan]Descargando datos consolidados del proveedor...[/cyan]")
        
        # Import dinámico para evitar dependencia circular
        from ..factory import ProviderFactory
        
        binance = ProviderFactory.create(provider)
        
        if data_type == "agg_trades":
            df = binance.fetch_agg_trades(
                symbol=ticker,
                year=year,
                month=month,
            )
        elif data_type == "klines":
            # Calcular rango de fechas para el mes
            from datetime import timezone
            from calendar import monthrange
            
            days_in_month = monthrange(year, month)[1]
            start_date = datetime(year, month, 1, tzinfo=timezone.utc)
            end_date = datetime(year, month, days_in_month, 23, 59, 59, tzinfo=timezone.utc)
            
            df = binance.fetch_history(
                symbol=ticker,
                start_date=start_date,
                end_date=end_date,
                granularity=granularity if granularity != "tick" else "1m"
            )
        else:
            raise ValueError(f"data_type debe ser 'klines' o 'agg_trades', no '{data_type}'")
        
        if df.is_empty():
            console.print(f"[yellow]⚠️ Sin datos disponibles para {year}-{month:02d}[/yellow]")
            return {
                "partitions_deleted": partitions_deleted,
                "rows_downloaded": 0,
                "path": None
            }
        
        console.print(f"[green]✓ Descargadas {len(df)} filas[/green]")
        
        # 3. Escribir como partición mensual (sin partition_by_day)
        result = self.write(
            df, ticker, provider, granularity,
            partition_by_day=False,
            overwrite=True
        )
        
        console.print(f"[bold green]✓ Consolidación completada: {result['paths'][0]}[/bold green]")
        
        return {
            "partitions_deleted": partitions_deleted,
            "rows_downloaded": len(df),
            "path": result["paths"][0] if result["paths"] else None
        }

# Wrappers
def write_partitioned(
    df: pl.DataFrame,
    base_path: Union[str, Path],
    ticker: str,
    provider: str,
    granularity: str = "tick",
    time_col: str = "time",
    compression: Literal["snappy", "gzip", "lz4", "zstd", "uncompressed"] = "snappy",
    overwrite: bool = True,
    partition_by_day: bool = False,
) -> Dict[str, Any]:
    """Wrapper para PartitionManager.write()."""
    manager = PartitionManager(base_path)
    return manager.write(df, ticker, provider, granularity, time_col, compression, overwrite, partition_by_day)

def read_partitioned(
    base_path: Union[str, Path],
    ticker: Optional[str] = None,
    provider: Optional[str] = None,
    granularity: Optional[str] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
) -> pl.DataFrame:
    """Wrapper para PartitionManager.read()."""
    manager = PartitionManager(base_path)
    return manager.read(
        ticker, provider, granularity, year, month, start_date, end_date
    )

def list_partitions(
    base_path: Union[str, Path],
    ticker: Optional[str] = None,
    provider: Optional[str] = None,
    granularity: Optional[str] = None,
) -> pl.DataFrame:
    """Wrapper para PartitionManager.list_partitions()."""
    manager = PartitionManager(base_path)
    return manager.list_partitions(ticker, provider, granularity)

def delete_partition(
    base_path: Union[str, Path],
    ticker: str,
    provider: str,
    granularity: str,
    year: int,
    month: int,
    day: Optional[int] = None,
    confirm: bool = False,
) -> bool:
    """Wrapper para PartitionManager.delete()."""
    manager = PartitionManager(base_path)
    return manager.delete(ticker, provider, granularity, year, month, day, confirm)

def compact_month(
    base_path: Union[str, Path],
    ticker: str,
    provider: str,
    granularity: str,
    year: int,
    month: int,
    confirm: bool = False,
) -> Dict[str, Any]:
    """Wrapper para PartitionManager.compact_month()."""
    manager = PartitionManager(base_path)
    return manager.compact_month(ticker, provider, granularity, year, month, confirm)

def rebuild_catalog(base_path: Union[str, Path]):
    """Wrapper para PartitionManager.rebuild_catalog()."""
    manager = PartitionManager(base_path)
    manager.rebuild_catalog()

def consolidate_from_source(
    base_path: Union[str, Path],
    ticker: str,
    provider: str,
    granularity: str,
    year: int,
    month: int,
    data_type: Literal["klines", "agg_trades"] = "agg_trades",
    confirm: bool = False,
) -> Dict[str, Any]:
    """Wrapper para PartitionManager.consolidate_from_source()."""
    manager = PartitionManager(base_path)
    return manager.consolidate_from_source(
        ticker, provider, granularity, year, month, data_type, confirm
    )