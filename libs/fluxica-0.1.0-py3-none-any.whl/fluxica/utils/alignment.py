# src/fluxica/utils/alignment.py
"""
Módulo de alineación temporal para DataFrames financieros.

Proporciona funciones para alinear múltiples series temporales
que pueden tener diferentes fechas de inicio, gaps, o frecuencias.
"""

import polars as pl
from typing import Dict, List, Optional, Literal
from datetime import timedelta


def align_dataframes(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str = "time",
    strategy: Literal["inner", "outer", "asof"] = "inner",
    tolerance: Optional[str] = "4d",
    fill_strategy: Optional[Literal["forward", "null"]] = "null",
    value_cols: Optional[List[str]] = None,
) -> pl.DataFrame:
    """
    Alinea múltiples DataFrames en un eje temporal común.
    
    Toma un diccionario de DataFrames (típicamente de fetch_multiple_tickers)
    y los combina en un único DataFrame con columnas prefijadas por ticker.
    
    Args:
        dataframes: Dict[str, pl.DataFrame] donde key es el identificador
                   (ej: ticker) y value es el DataFrame con columna temporal.
        time_col: Nombre de la columna temporal (default: "time")
        strategy: Estrategia de alineación:
            - "inner": Solo timestamps presentes en TODOS los DataFrames.
                      Resultado más pequeño, sin nulls, máxima integridad.
            - "outer": TODOS los timestamps de cualquier DataFrame.
                      Resultado más grande, puede tener nulls.
            - "asof": Backward join usando el primer DataFrame como master.
                      Útil para frecuencias mixtas (ej: Forex M1 + Stocks 1d).
        tolerance: Para strategy="asof", máxima distancia temporal permitida.
                  Formato Polars duration string: "4d", "1h", "30m".
                  Si el gap excede tolerance, el valor será null.
        fill_strategy: Qué hacer con nulls después del join:
            - "null": Mantener nulls (default)
            - "forward": Forward-fill dentro de cada ticker
        value_cols: Columnas de valores a incluir. Si None, usa OHLCV estándar.
                   
    Returns:
        DataFrame unificado con estructura:
        | time | AAPL_close | AAPL_volume | MSFT_close | MSFT_volume | ...
        
    Raises:
        ValueError: Si dataframes está vacío o algún DataFrame no tiene time_col
        
    Example:
        >>> dfs = provider.fetch_multiple_tickers(["AAPL", "MSFT"], start, end)
        >>> aligned = align_dataframes(dfs, strategy="inner")
        >>> print(aligned.columns)
        ['time', 'AAPL_open', 'AAPL_high', ..., 'MSFT_open', 'MSFT_high', ...]
        
    Notas:
        - Para strategy="asof", el PRIMER DataFrame en el dict es el master.
          El orden de inserción en Python 3.7+ está garantizado.
        - Todos los DataFrames deben tener la columna time_col en UTC.
        - Los DataFrames se ordenan por time_col antes del join.
    """
    if not dataframes:
        raise ValueError("dataframes no puede estar vacío")
    
    # Columnas de valor por defecto
    if value_cols is None:
        value_cols = ["open", "high", "low", "close", "volume"]
    
    # Validar y preparar DataFrames
    prepared = _prepare_dataframes(dataframes, time_col, value_cols)
    
    if not prepared:
        raise ValueError("Ningún DataFrame tiene las columnas requeridas")
    
    # Aplicar estrategia de alineación
    if strategy == "inner":
        result = _align_inner(prepared, time_col)
    elif strategy == "outer":
        result = _align_outer(prepared, time_col)
    elif strategy == "asof":
        result = _align_asof(prepared, time_col, tolerance)
    else:
        raise ValueError(f"Estrategia '{strategy}' no soportada. Use: inner, outer, asof")
    
    # Aplicar fill_strategy si se especificó
    if fill_strategy == "forward" and not result.is_empty():
        result = _apply_forward_fill(result, time_col)
    
    return result.sort(time_col)


def _prepare_dataframes(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str,
    value_cols: List[str]
) -> Dict[str, pl.DataFrame]:
    """
    Prepara DataFrames: valida, ordena, y renombra columnas con prefijo.
    """
    prepared = {}
    
    for name, df in dataframes.items():
        if df.is_empty():
            continue
            
        if time_col not in df.columns:
            raise ValueError(f"DataFrame '{name}' no tiene columna '{time_col}'")
        
        # Columnas disponibles para este DataFrame
        available_cols = [c for c in value_cols if c in df.columns]
        
        if not available_cols:
            continue
        
        # Seleccionar y renombrar columnas
        select_cols = [time_col] + available_cols
        df_subset = df.select(select_cols).sort(time_col)
        
        # Renombrar columnas de valores con prefijo del ticker
        rename_map = {col: f"{name}_{col}" for col in available_cols}
        df_renamed = df_subset.rename(rename_map)
        
        prepared[name] = df_renamed
    
    return prepared


def _align_inner(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str
) -> pl.DataFrame:
    """
    Inner join: solo timestamps presentes en TODOS los DataFrames.
    """
    names = list(dataframes.keys())
    
    if len(names) == 1:
        return dataframes[names[0]]
    
    # Empezar con el primero
    result = dataframes[names[0]]
    
    # Inner join secuencial
    for name in names[1:]:
        result = result.join(
            dataframes[name],
            on=time_col,
            how="inner"
        )
    
    return result


def _align_outer(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str
) -> pl.DataFrame:
    """
    Outer join: todos los timestamps de cualquier DataFrame.
    Timestamps faltantes tendrán null en las columnas correspondientes.
    """
    names = list(dataframes.keys())
    
    if len(names) == 1:
        return dataframes[names[0]]
    
    # Empezar con el primero
    result = dataframes[names[0]]
    
    # Full outer join secuencial
    for name in names[1:]:
        result = result.join(
            dataframes[name],
            on=time_col,
            how="full",
            coalesce=True  # Unificar columna time de ambos lados
        )
    
    return result


def _align_asof(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str,
    tolerance: Optional[str]
) -> pl.DataFrame:
    """
    ASOF join: el primer DataFrame es el master (índice temporal base).
    
    Para cada timestamp en el master, busca el valor más reciente
    disponible en los otros DataFrames (backward strategy).
    
    Útil cuando:
    - El master tiene mayor frecuencia (ej: Forex M1)
    - Los secundarios tienen menor frecuencia (ej: Stocks 1d)
    """
    names = list(dataframes.keys())
    
    if len(names) == 1:
        return dataframes[names[0]]
    
    # El primero es el master
    result = dataframes[names[0]]
    
    # ASOF join secuencial
    for name in names[1:]:
        right = dataframes[name]
        
        # join_asof requiere que ambos estén ordenados
        result = result.sort(time_col)
        right = right.sort(time_col)
        
        join_kwargs = {
            "on": time_col,
            "strategy": "backward",  # Último valor conocido
        }
        
        if tolerance is not None:
            join_kwargs["tolerance"] = tolerance
        
        result = result.join_asof(right, **join_kwargs)
    
    return result


def _apply_forward_fill(df: pl.DataFrame, time_col: str) -> pl.DataFrame:
    """
    Aplica forward-fill a todas las columnas excepto time_col.
    """
    value_cols = [c for c in df.columns if c != time_col]
    
    return df.with_columns([
        pl.col(c).forward_fill() for c in value_cols
    ])


def get_alignment_summary(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str = "time"
) -> pl.DataFrame:
    """
    Genera un resumen de cobertura temporal de cada DataFrame.
    
    Útil para diagnosticar antes de alinear: ver qué tickers tienen
    gaps, diferentes rangos de fechas, o datos faltantes.
    
    Args:
        dataframes: Dict de DataFrames a analizar
        time_col: Columna temporal
        
    Returns:
        DataFrame con columnas:
        - ticker: nombre del ticker
        - start: primera fecha
        - end: última fecha  
        - count: número de filas
        - gaps: número de días sin datos (estimado)
        
    Example:
        >>> summary = get_alignment_summary(dfs)
        >>> print(summary)
        shape: (3, 5)
        ┌────────┬────────────┬────────────┬───────┬──────┐
        │ ticker │ start      │ end        │ count │ gaps │
        │ str    │ datetime   │ datetime   │ u32   │ i64  │
        ╞════════╪════════════╪════════════╪═══════╪══════╡
        │ AAPL   │ 2020-01-02 │ 2024-01-15 │ 1008  │ 0    │
        │ MSFT   │ 2020-01-02 │ 2024-01-15 │ 1006  │ 2    │
        │ GOOGL  │ 2020-01-03 │ 2024-01-15 │ 1007  │ 1    │
        └────────┴────────────┴────────────┴───────┴──────┘
    """
    def _analyze_dataframe(name: str, df: pl.DataFrame) -> dict:
        if df.is_empty() or time_col not in df.columns:
            return {
                "ticker": name,
                "start": None,
                "end": None,
                "count": 0,
                "gaps_estimate": 0,
            }
        
        df_sorted = df.sort(time_col)
        start = df_sorted[time_col].min()
        end = df_sorted[time_col].max()
        count = len(df_sorted)
        
        # Estimate expected trading days
        if start is not None and end is not None:
            total_days = (end - start).days
            expected_trading = int(total_days * 252 / 365)
            gaps = max(0, expected_trading - count)
        else:
            gaps = 0
            
        return {
            "ticker": name,
            "start": start,
            "end": end,
            "count": count,
            "gaps_estimate": gaps,
        }

    summaries = [_analyze_dataframe(name, df) for name, df in dataframes.items()]
    
    return pl.DataFrame(summaries)


def find_common_date_range(
    dataframes: Dict[str, pl.DataFrame],
    time_col: str = "time"
) -> tuple[Optional[pl.Datetime], Optional[pl.Datetime]]:
    """
    Encuentra el rango de fechas común a TODOS los DataFrames.
    
    Returns:
        Tupla (max_start, min_end) representando el rango común.
        Si no hay intersección, retorna (None, None).
        
    Example:
        >>> start, end = find_common_date_range(dfs)
        >>> if start and end:
        ...     print(f"Rango común: {start} a {end}")
    """
    # Filter valid dataframes first
    valid_dfs = [
        df for df in dataframes.values() 
        if not df.is_empty() and time_col in df.columns
    ]
    
    if not valid_dfs:
        return (None, None)
    
    # Calculate min/max directly using generator expressions
    common_start = max(df[time_col].min() for df in valid_dfs)
    common_end = min(df[time_col].max() for df in valid_dfs)
    
    if common_start > common_end:
        return (None, None)  # No intersection
    
    return (common_start, common_end)