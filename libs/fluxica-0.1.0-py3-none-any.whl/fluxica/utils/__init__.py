# src/fluxica/utils/__init__.py

from .normalization import (
    normalize_column_names,
    normalize_ohlcv_names,
    normalize_timezone_to_utc,
    ensure_float64_prices,
    ensure_int64_volume,
)

from .cleaning import (
    handle_missing_values,
    remove_duplicates,
    filter_trading_hours,
    validate_ohlc_integrity,
)

from .alignment import (
    align_dataframes,
    get_alignment_summary,
    find_common_date_range,
)

from .persistence import (
    PartitionManager,
    compact_month,
    consolidate_from_source,
    write_partitioned,
    read_partitioned,
    list_partitions,
    delete_partition,
    rebuild_catalog,
)

__all__ = [
    # Normalization
    "normalize_column_names",
    "normalize_ohlcv_names", 
    "normalize_timezone_to_utc",
    "ensure_float64_prices",
    "ensure_int64_volume",
    # Cleaning
    "handle_missing_values",
    "remove_duplicates",
    "filter_trading_hours",
    "validate_ohlc_integrity",
    # Alignment
    "align_dataframes",
    "get_alignment_summary",
    "find_common_date_range",
    # Persistence (Hive-style partitioning)
    "PartitionManager",
    "compact_month",
    "consolidate_from_source",
    "write_partitioned",
    "read_partitioned",
    "list_partitions",
    "delete_partition",
    "rebuild_catalog",
]