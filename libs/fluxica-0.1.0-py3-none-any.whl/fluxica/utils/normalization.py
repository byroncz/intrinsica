# src/fluxica/utils/normalization.py

import polars as pl
from datetime import datetime, timezone
from typing import Optional, Literal


def normalize_column_names(df: pl.DataFrame) -> pl.DataFrame:
    """
    Estandariza nombres de columnas a minúsculas.
    
    Yahoo retorna 'Open', 'High', etc.
    Oanda retorna 'o', 'h', etc.
    Salida estándar: 'open', 'high', etc.
    """
    rename_map = {col: col.lower() for col in df.columns}
    return df.rename(rename_map)


def normalize_ohlcv_names(df: pl.DataFrame) -> pl.DataFrame:
    """
    Mapea nombres de columnas comunes al schema estándar.
    
    Maneja variaciones como:
    - 'Date' / 'Datetime' / 'timestamp' -> 'time'
    - 'o' / 'Open' -> 'open'
    - 'vol' / 'Volume' -> 'volume'
    """
    # Primero, todo a minúsculas
    df = normalize_column_names(df)
    
    # Mapeo de variaciones conocidas
    column_aliases = {
        "date": "time",
        "datetime": "time",
        "timestamp": "time",
        "o": "open",
        "h": "high",
        "l": "low",
        "c": "close",
        "v": "volume",
        "vol": "volume",
    }
    
    # Aplicar renombrado solo si la columna existe
    rename_map = {
        old: new 
        for old, new in column_aliases.items() 
        if old in df.columns and new not in df.columns
    }
    
    if rename_map:
        df = df.rename(rename_map)
    
    return df


def normalize_timezone_to_utc(
    df: pl.DataFrame, 
    time_col: str = "time",
    time_unit: Literal["ns", "us", "ms"] = "ns"
) -> pl.DataFrame:
    """
    Convierte columna temporal a UTC explícito con unidad de tiempo específica.
    
    Maneja tres casos:
    1. Timestamp naive (sin zona) -> asume America/New_York, convierte a UTC
    2. Timestamp con zona -> convierte a UTC
    3. String -> parsea, asume NY si no tiene zona, y convierte a UTC
    
    Args:
        df: DataFrame con columna temporal
        time_col: Nombre de la columna temporal
        time_unit: Precisión de tiempo deseada ('ns', 'us', 'ms'). Default: 'ns'.
        
    Returns:
        DataFrame con columna temporal en UTC y la unidad especificada.
    """
    if time_col not in df.columns:
        raise ValueError(f"Columna '{time_col}' no encontrada")
    
    col_dtype = df.schema[time_col]
    
    # Función interna para cast final
    def _enforce_unit(dframe: pl.DataFrame) -> pl.DataFrame:
        return dframe.with_columns(
            pl.col(time_col).cast(pl.Datetime(time_unit, "UTC"))
        )
    
    # Caso 1: Ya es datetime
    if col_dtype in (pl.Datetime, pl.Date) or str(col_dtype).startswith("Datetime"):
        # Verificar si es naive mirando el tipo de dato
        time_zone = getattr(col_dtype, "time_zone", None)
        
        if time_zone is None:
            # Es naive - asignar NY primero, luego UTC
            df = df.with_columns(
                pl.col(time_col)
                .dt.replace_time_zone("America/New_York", ambiguous="earliest")
                .dt.convert_time_zone("UTC")
            )
        else:
            # convert_time_zone funciona bien si ya tiene zona
            df = df.with_columns(
                pl.col(time_col).dt.convert_time_zone("UTC")
            )
        return _enforce_unit(df)
    
    # Caso 2: Es string - parsear primero
    if col_dtype == pl.Utf8 or col_dtype == pl.String:
        # Intentar parsear
        df = df.with_columns(
            pl.col(time_col).str.to_datetime(strict=False) # strict=False para tolerar fallos si hay basura
        )
        # Recursión para aplicar la lógica de timezone
        return normalize_timezone_to_utc(df, time_col, time_unit)
    
    raise TypeError(f"Tipo no soportado para '{time_col}': {col_dtype}")


def ensure_float64_prices(df: pl.DataFrame) -> pl.DataFrame:
    """
    Convierte columnas OHLC a Float64.
    
    Algunos proveedores retornan strings o enteros.
    """
    price_cols = ["open", "high", "low", "close"]
    existing = [c for c in price_cols if c in df.columns]
    
    return df.with_columns([
        pl.col(c).cast(pl.Float64) for c in existing
    ])


def ensure_int64_volume(df: pl.DataFrame) -> pl.DataFrame:
    """
    Convierte columna volume a Int64.
    
    Maneja nulos convirtiéndolos a 0.
    """
    if "volume" not in df.columns:
        return df
    
    return df.with_columns(
        pl.col("volume").fill_null(0).cast(pl.Int64)
    )