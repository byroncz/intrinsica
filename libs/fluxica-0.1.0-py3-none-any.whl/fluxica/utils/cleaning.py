# src/fluxica/utils/cleaning.py

import polars as pl
from datetime import timedelta
from typing import Optional, List


def handle_missing_values(
    df: pl.DataFrame, 
    max_gap_days: int = 3,
    price_cols: Optional[List[str]] = None
) -> pl.DataFrame:
    """
    Aplica forward-fill controlado para gaps genuinos.
    
    REGLA CRÍTICA: Fines de semana y feriados NO son valores faltantes.
    Solo aplicar forward-fill cuando hay gaps genuinos (mercado abierto
    pero sin datos).
    
    Args:
        df: DataFrame ordenado por 'time'
        max_gap_days: Máximo de días para propagar valores (default: 3)
        price_cols: Columnas a rellenar (default: OHLC + volume)
        
    Returns:
        DataFrame con forward-fill aplicado respetando el límite
    """
    if df.is_empty():
        return df
    
    if "time" not in df.columns:
        raise ValueError("DataFrame debe tener columna 'time'")
    
    # Columnas por defecto
    if price_cols is None:
        price_cols = ["open", "high", "low", "close", "volume"]
    
    # Filtrar solo columnas existentes
    cols_to_fill = [c for c in price_cols if c in df.columns]
    
    if not cols_to_fill:
        return df
    
    # Forward fill con límite
    # Polars no tiene forward_fill con límite directo, 
    # así que calculamos manualmente
    
    df = df.sort("time")
    
    # Calculate last valid time for each column to determine gap duration
    for col_name in cols_to_fill:
        # Create validity mask
        is_valid = pl.col(col_name).is_not_null()
        
        # Get timestamp of the last valid observation
        # 1. Take time where value is valid
        # 2. Forward fill this time to null positions
        last_valid_time = (
            pl.when(is_valid)
            .then(pl.col("time"))
            .otherwise(None)
            .forward_fill()
        )
        
        # Calculate duration since last valid value
        time_since_valid = pl.col("time") - last_valid_time
        
        # Condition: Valid gap if within max_gap_days
        # Note: We use timedelta for comparison
        is_fillable = time_since_valid <= timedelta(days=max_gap_days)
        
        # Apply forward fill but revert to null if gap is too large
        df = df.with_columns(
            pl.when(is_fillable)
            .then(pl.col(col_name).forward_fill())
            .otherwise(None)
            .alias(col_name)
        )
    
    return df


def remove_duplicates(
    df: pl.DataFrame, 
    subset: Optional[List[str]] = None,
    keep: str = "first"
) -> pl.DataFrame:
    """
    Elimina filas duplicadas basándose en columnas específicas.
    
    Args:
        df: DataFrame de entrada
        subset: Columnas para determinar duplicados (default: ['time'])
        keep: 'first' o 'last' - cuál duplicado mantener
        
    Returns:
        DataFrame sin duplicados
    """
    if df.is_empty():
        return df
    
    if subset is None:
        subset = ["time"] if "time" in df.columns else df.columns[:1]
    
    return df.unique(subset=subset, keep=keep)


def filter_trading_hours(
    df: pl.DataFrame,
    market_open: int = 9,
    market_close: int = 16,
    timezone: str = "America/New_York"
) -> pl.DataFrame:
    """
    Filtra datos fuera del horario de mercado.
    
    Útil para acciones donde solo importa el horario regular.
    NO usar para Forex (24 horas).
    
    Args:
        df: DataFrame con columna 'time' en UTC
        market_open: Hora de apertura (default: 9)
        market_close: Hora de cierre (default: 16)
        timezone: Zona horaria del mercado
        
    Returns:
        DataFrame filtrado
    """
    if df.is_empty() or "time" not in df.columns:
        return df
    
    # Convertir a zona horaria del mercado para filtrar
    df_local = df.with_columns(
        pl.col("time").dt.convert_time_zone(timezone).alias("_local_time")
    )
    
    # Filtrar por hora
    df_filtered = df_local.filter(
        (pl.col("_local_time").dt.hour() >= market_open) &
        (pl.col("_local_time").dt.hour() < market_close)
    ).drop("_local_time")
    
    return df_filtered


def validate_ohlc_integrity(df: pl.DataFrame) -> pl.DataFrame:
    """
    Valida y corrige integridad de datos OHLC.
    
    Reglas:
    - high >= max(open, close)
    - low <= min(open, close)
    - high >= low
    
    Filas que violan estas reglas se marcan o corrigen.
    
    Returns:
        DataFrame con columna '_ohlc_valid' (bool)
    """
    if df.is_empty():
        return df.with_columns(pl.lit(True).alias("_ohlc_valid"))
    
    required = ["open", "high", "low", "close"]
    if not all(c in df.columns for c in required):
        return df.with_columns(pl.lit(True).alias("_ohlc_valid"))
    
    return df.with_columns(
        (
            (pl.col("high") >= pl.col("open")) &
            (pl.col("high") >= pl.col("close")) &
            (pl.col("low") <= pl.col("open")) &
            (pl.col("low") <= pl.col("close")) &
            (pl.col("high") >= pl.col("low"))
        ).alias("_ohlc_valid")
    )