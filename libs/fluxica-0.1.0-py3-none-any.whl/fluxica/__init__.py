# src/fluxica/__init__.py
"""
fluxica - Librería agnóstica de adquisición de datos financieros

Uso básico:
    >>> from fluxica import ProviderFactory
    >>> 
    >>> # Crear proveedor
    >>> yahoo = ProviderFactory.create("yahoo")
    >>> 
    >>> # Descargar datos
    >>> from datetime import datetime, timedelta
    >>> end = datetime.now()
    >>> start = end - timedelta(days=365)
    >>> df = yahoo.fetch_history("AAPL", start, end)
    >>> 
    >>> # df es un DataFrame de Polars con schema estandarizado

Proveedores disponibles:
    - "yahoo": Acciones, ETFs, Índices (no requiere autenticación)
    - "oanda": Forex (requiere api_token) [próximamente]
    - "fred": Datos macro (requiere api_key) [próximamente]
"""

from .interfaces import DataProvider
from .factory import ProviderFactory

__all__ = [
    "DataProvider",
    "ProviderFactory",
]

__version__ = "0.1.0"